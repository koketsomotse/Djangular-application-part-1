export class Customer {
    id: number;
    name: string;
    surname: string;
    email: string;
    number: number;
}